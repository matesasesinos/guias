<?php
 //validator: https://github.com/infinitypaul/php-validator/
defined("DBDRIVER") or define('DBDRIVER','mysql');
defined("DBHOST") or define('DBHOST','localhost');
defined("DBNAME") or define('DBNAME','guias');
defined("DBUSER") or define('DBUSER','root');
defined("DBPASS") or define('DBPASS','');